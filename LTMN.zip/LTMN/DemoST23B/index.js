const express = require('express');
const app = express();

// Route Trang chủ
app.get('/', (req, res) => {
    res.send('Trang chủ - Server đang chạy!');
});

app.get('/about', (req, res) => {
    res.send('Hello Page');
});


app.listen(4000, () => {
    console.log('Server running on port 4000');
});
